import { StyleSheet, Text, View, TouchableOpacity, Image, FlatList,Dimensions, Pressable } from "react-native";
import React from "react";
import { useNavigation } from "expo-router";

const data = [
  {
    id: "1",
    title: "Appetizers",
    image: require("../assets/images/appetizer.png"),
    screen: "AppetizersList",
  },
  {
    id: "2",
    title: "Salads",
    image: require("../assets/images/salads.png"),
    screen: "SaladsList",
  },
  {
    id: "3",
    title: "Main Dishes",
    image: require("../assets/images/maindish.png"),
    screen: "MainDishes",
  },
  {
    id: "4",
    title: "Soups",
    image: require("../assets/images/soups.png"),
    screen: "SoupsList",
  },
];
const CategoryList = () => {
  const navigation = useNavigation();

  const renderItem = ({item}) => (
    <Pressable
      style={styles.card}
      onPress={() => navigation.navigate(item.screen)}
    >
      <Image source={item.image} style={styles.image} />
      <View style={styles.textOverlay}>
        <Text style={styles.text}>{item.title}</Text>
      </View>
    </Pressable>
  );
  return (
    <View>
     <View style={styles.cardContainer}>
          <FlatList
            data={data}
            numColumns={2}
            renderItem={renderItem}
            keyExtractor={(item) => item.id}
            showsHorizontalScrollIndicator={false}
            columnWrapperStyle={styles.row}
          />
        </View>
    </View>
  );
};

export default CategoryList;

const styles = StyleSheet.create({
    cardContainer:{
        marginTop: 20
    },
    card: {
        width: 170,
        height: 250,
        backgroundColor: "#000000",
        borderWidth: 1,
        borderColor: "grey",
        borderRadius: 10,
        marginHorizontal: 5,
        alignItems: "center",
      },
      image: {
        width: 170,
        height: 250,
        borderRadius: 10,
      },
      textOverlay: {
        position: 'absolute',
        bottom: 10, 
        left: 0,
        right: 0,
        alignItems: 'center',
      },
      text: {
        fontSize: 16,
        fontWeight: "bold",
        color: "#fff",
        paddingHorizontal: 5,
        paddingVertical: 2,
        borderRadius: 5,
      },
      row: {
        justifyContent: 'space-between',
        marginBottom: 20,
      },
});
