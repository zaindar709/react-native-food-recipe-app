import React, { useEffect } from 'react';
import { View, Text } from 'react-native';
import * as SplashScreen from 'expo-splash-screen';

SplashScreen.preventAutoHideAsync();

export default function App() {

  useEffect(() => {
    const timer = setTimeout(async () => {
      await SplashScreen.hideAsync(); 
    }, 3000);

    return () => clearTimeout(timer); 
  }, []);

  return (
    <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
      <Text>Welcome to the FoodRecipe App!</Text>
    </View>
  );
}
