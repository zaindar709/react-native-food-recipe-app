import { StyleSheet, Text, View, TouchableOpacity, Image } from "react-native";
import React, { useState } from "react";
import { useNavigation, useRouter } from "expo-router";

const Cooked = () => {
  const navigation = useNavigation();
  const [activeTab, setActiveTab] = useState("Cooked");

  return (
    <View style={styles.container}>
      <View style={styles.tabsContainer}>
        <TouchableOpacity
          style={[styles.tab, activeTab === "Favorites" && styles.activeTab]}
          onPress={() => {
            setActiveTab("Favorites");
            navigation.replace("(tabs)", { screen: "Favorites" });
          }}
        >
          <Text
            style={[
              styles.tabText,
              activeTab === "Favorites" && styles.activeTabText,
            ]}
          >
            Favorites
          </Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[styles.tab, activeTab === "Cooked" && styles.activeTab]}
          onPress={() => {
            setActiveTab("Cooked");
          }}
        >
          <Text
            style={[
              styles.tabText,
              activeTab === "Cooked" && styles.activeTabText,
            ]}
          >
            Cooked
          </Text>
        </TouchableOpacity>
      </View>
      <Text style={styles.yetText}>You have not add any recipe {"\n"} yet</Text>
      <Text style={styles.searchText}>
        Use the button Search on the bottom panel
      </Text>
      <Text style={styles.centeredText}>to find the recipe you need</Text>
      <View style={{ marginTop: 50 }}>
        <Image
          source={require("../assets/images/search.png")}
          style={styles.searchImage}
        />
        <Text style={styles.searchImageText}>To add recipe click Cooked</Text>
      </View>
    </View>
  );
};

export default Cooked;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#333",
    paddingTop: 20,
  },
  tabsContainer: {
    flexDirection: "row",
    justifyContent: "space-around",
    marginBottom: 10,
  },
  tab: {
    paddingBottom: 8,
  },
  activeTab: {
    borderBottomWidth: 2,
    borderBottomColor: "skyblue",
  },
  tabText: {
    color: "grey",
    fontSize: 16,
  },
  activeTabText: {
    color: "skyblue",
    fontWeight: "bold",
  },
  yetText: {
    textAlign: "center",
    marginTop: 30,
    fontSize: 20,
    color: "white",
  },
  searchText: {
    color: "grey",
    alignSelf: "center",
    marginTop: 20,
    fontSize: 15,
  },
  searchImage: {
    width: 150,
    height: 200,
    alignSelf: "center",
    resizeMode: "contain",
  },
  searchImageText: {
    color: "grey",
    fontSize: 16,
    fontWeight: "bold",
    alignSelf: "center",
  },
  centeredText: {
    alignSelf: "center",
    color: "grey",
    fontSize: 15,
  },
});
