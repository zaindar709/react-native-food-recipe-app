// app/index.tsx
import React from 'react';

import MainStack from './MainStack';
import { LogBox } from 'react-native';

LogBox.ignoreAllLogs(true);
const App = () => {
  return (
    
    <MainStack />
   
  );
};

export default App;
