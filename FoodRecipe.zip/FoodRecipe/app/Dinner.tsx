import {
    StyleSheet,
    Text,
    View,
    TouchableOpacity,
    Image,
    Modal,
    Dimensions,
    Pressable
  } from "react-native";
  import React, { useState } from "react";
  import { FlatList } from "react-native-gesture-handler";
  import { GestureHandlerRootView } from "react-native-gesture-handler"; 
  
  const data = [
    {
      id: "1",
      title: "Chicken Alfredo Pasta",
      image: require('../assets/images/chickenalfredopasta.jpeg'), 
      Description:
        "\nA creamy chicken Alfredo pasta that’s rich and satisfying. This dish is perfect for a comforting dinner and is easy to prepare.",
      Ingredients:
        "\n• 8 oz fettuccine pasta\n• 2 chicken breasts, cooked and sliced\n• 1 cup heavy cream\n• 1/2 cup grated Parmesan cheese\n• 2 tbsp butter\n• 2 cloves garlic, minced\n• Salt and pepper to taste\n• Fresh parsley for garnish (optional)",
      Instructions:
        "\n1. Cook fettuccine according to package instructions; drain and set aside.\n2. In a skillet, melt butter over medium heat. Add garlic and sauté until fragrant.\n3. Pour in heavy cream and bring to a simmer. Stir in Parmesan cheese until melted.\n4. Add the cooked pasta and chicken, mixing well to coat.\n5. Season with salt and pepper, garnish with parsley, and serve warm.",
    },
    {
      id: "2",
      title: "Beef Tacos",
      image: require('../assets/images/beeftacos.jpeg'), 
      Description:
        "\nThese flavorful beef tacos are easy to make and perfect for a fun dinner. Customize with your favorite toppings for a delicious meal.",
      Ingredients:
        "\n• 1 lb ground beef\n• 1 taco seasoning packet\n• 8 taco shells\n• 1 cup lettuce, shredded\n• 1 cup tomatoes, diced\n• 1/2 cup shredded cheese\n• Salsa and sour cream for serving",
      Instructions:
        "\n1. In a skillet, cook ground beef over medium heat until browned. Drain excess fat.\n2. Add taco seasoning and follow package instructions.\n3. Warm taco shells in the oven according to package instructions.\n4. Fill each shell with beef and top with lettuce, tomatoes, cheese, and your favorite condiments.\n5. Serve immediately with salsa and sour cream.",
    },
    {
      id: "3",
      title: "Stuffed Zucchini Boats",
      image: require('../assets/images/stuffedzuchinni.jpeg'), 
      Description:
        "\nThese stuffed zucchini boats are a healthy and flavorful dinner option, filled with ground turkey, spices, and topped with cheese.",
      Ingredients:
        "\n• 4 medium zucchini\n• 1 lb ground turkey\n• 1 can diced tomatoes\n• 1/2 onion, chopped\n• 1 tsp Italian seasoning\n• Salt and pepper to taste\n• 1 cup shredded mozzarella cheese\n• Fresh basil for garnish (optional)",
      Instructions:
        "\n1. Preheat the oven to 375°F (190°C).\n2. Halve zucchini lengthwise and scoop out seeds.\n3. In a skillet, cook ground turkey and onion until browned. Stir in diced tomatoes, Italian seasoning, salt, and pepper.\n4. Fill each zucchini half with the mixture and place in a baking dish.\n5. Top with mozzarella cheese and bake for 25-30 minutes until zucchini is tender. Garnish with fresh basil before serving.",
    },
    {
      id: "4",
      title: "Shrimp Fried Rice",
      image: require('../assets/images/shrimpfriedrice.jpeg'), 
      Description:
        "\nA quick and delicious shrimp fried rice dish that’s loaded with flavor and perfect for a satisfying dinner.",
      Ingredients:
        "\n• 2 cups cooked rice (preferably day-old)\n• 1 lb shrimp, peeled and deveined\n• 2 eggs, beaten\n• 1 cup mixed vegetables (peas, carrots, corn)\n• 2 tbsp soy sauce\n• 2 green onions, chopped\n• 2 tbsp vegetable oil\n• Salt and pepper to taste",
      Instructions:
        "\n1. In a large skillet or wok, heat vegetable oil over medium-high heat. Add shrimp and cook until pink and opaque; remove and set aside.\n2. In the same skillet, add mixed vegetables and sauté for 2-3 minutes. Push to one side of the pan and pour in beaten eggs, scrambling until cooked.\n3. Add the cooked rice, shrimp, soy sauce, and green onions. Stir to combine and cook until heated through.\n4. Season with salt and pepper to taste and serve warm.",
    },
  ];
  
  
  
  const Dinner = () => {
    const [modalVisible, setModalVisible] = useState(false);
    const [selectedItems, setSelectedItems] = useState(null);
  
    const renderItem = ({ item }) => (
      <Pressable
        style={styles.card}
        onPress={() => {
          setSelectedItems(item);
          setModalVisible(true);
        }}
      >
        <Image source={item.image} style={styles.image} />
        <Text style={styles.cardTitle}>{item.title}</Text>
      </Pressable>
    );
  
    const closeModal = () => {
      setModalVisible(false);
      setSelectedItems(null);
    };
  
    return (
      <GestureHandlerRootView style={{ flex: 1, backgroundColor:'black' }}>
        <Text style={styles.text}>Dinner</Text>
        <FlatList
        style={{marginTop: 30}}
          data={data}
          renderItem={renderItem}
          keyExtractor={(item) => item.id}
          numColumns={2}
          columnWrapperStyle={styles.row}
        />
        <Modal
          visible={modalVisible}
          animationType="slide"
          onRequestClose={closeModal}
        >
          <View style={styles.modalContainer}>
            {selectedItems && (
              <>
                <Text style={styles.modalTitle}>{selectedItems.title}</Text>
                <Text style={styles.modalDescription}>
                  {selectedItems.Description}
                </Text>
                <Text style={styles.modalIngredients}>
                  Ingredients:{selectedItems.Ingredients}
                </Text>
                <Text style={styles.modalInstructions}>
                  Instructions:{selectedItems.Instructions}
                </Text>
                <TouchableOpacity style={styles.closeButton} onPress={closeModal}>
                  <Text style={styles.closeButtonText}>Close</Text>
                </TouchableOpacity>
              </>
            )}
          </View>
        </Modal>
      </GestureHandlerRootView>
    );
  };
  
  export default Dinner;
  
  const styles = StyleSheet.create({
    text: {
      fontSize: 25,
      fontWeight: "bold",
      color: "white",
      textAlign: "center",
      marginTop: "10%",
    },
    row: {
      justifyContent: "space-between",
    },
    card: {
      height: 270,
      width: 170,
      backgroundColor: "#000000",
      borderWidth: 1,
      borderRadius: 10,
      borderColor: "grey",
      marginBottom: 20,
      alignItems: "center",
      justifyContent: "center",
      padding: 10,
      marginHorizontal: 5,
    },
    image: {
      width: "100%",
      height: 170,
      borderRadius: 10,
      marginBottom: 10,
    },
    cardTitle: {
      color: "white",
      fontSize: 18,
      fontWeight: "bold",
      textAlign: "center",
    },
    modalContainer: {
      flex: 1,
      backgroundColor: "white",
      padding: 20,
    },
    modalTitle: {
      fontSize: 24,
      fontWeight: "bold",
      marginBottom: 10,
    },
    modalDescription: {
      fontSize: 16,
      marginBottom: 10,
    },
    modalIngredients: {
      fontSize: 16,
      marginBottom: 10,
    },
    modalInstructions: {
      fontSize: 16,
      marginBottom: 20,
    },
    closeButton: {
      backgroundColor: "#FFA500",
      padding: 10,
      borderRadius: 5,
      alignItems: "center",
    },
    closeButtonText: {
      color: "white",
      fontWeight: "bold",
    },
  });
  