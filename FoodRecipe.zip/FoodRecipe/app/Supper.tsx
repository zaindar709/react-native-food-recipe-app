import {
    StyleSheet,
    Text,
    View,
    TouchableOpacity,
    Image,
    Modal,
    Dimensions,
    Pressable
  } from "react-native";
  import React, { useState } from "react";
  import { FlatList } from "react-native-gesture-handler";
  import { GestureHandlerRootView } from "react-native-gesture-handler"; 
  
  const data = [
    {
      id: "1",
      title: "Lentil Soup",
      image: require('../assets/images/lentilsoup.jpeg'),
      Description:
        "\nA hearty lentil soup packed with flavor and nutrition. It's a comforting supper that warms you up and is perfect for chilly evenings.",
      Ingredients:
        "\n• 1 cup lentils (green or brown)\n• 1 onion, chopped\n• 2 carrots, diced\n• 2 celery stalks, diced\n• 2 cloves garlic, minced\n• 4 cups vegetable or chicken broth\n• 1 tsp cumin\n• 1 tsp thyme\n• Salt and pepper to taste\n• 2 tbsp olive oil",
      Instructions:
        "\n1. In a large pot, heat olive oil over medium heat. Add onions, carrots, and celery; sauté until softened.\n2. Add garlic, cumin, and thyme; cook for 1 minute until fragrant.\n3. Stir in lentils and broth, bring to a boil.\n4. Reduce heat and simmer for 25-30 minutes until lentils are tender.\n5. Season with salt and pepper to taste and serve warm.",
    },
    {
      id: "2",
      title: "Baked Salmon with Vegetables",
      image: require('../assets/images/salmon.jpeg'),
      Description:
        "\nThis baked salmon dish is healthy and delicious, served with roasted vegetables for a complete meal that's perfect for supper.",
      Ingredients:
        "\n• 2 salmon fillets\n• 1 zucchini, sliced\n• 1 bell pepper, sliced\n• 1 cup broccoli florets\n• 2 tbsp olive oil\n• 1 lemon, sliced\n• Salt and pepper to taste\n• Fresh dill for garnish (optional)",
      Instructions:
        "\n1. Preheat the oven to 400°F (200°C).\n2. Place salmon and vegetables on a baking sheet, drizzle with olive oil, and season with salt and pepper.\n3. Top salmon with lemon slices.\n4. Bake for 15-20 minutes until salmon is cooked through and vegetables are tender.\n5. Garnish with fresh dill if desired and serve warm.",
    },
    {
      id: "3",
      title: "Stuffed Bell Peppers",
      image: require('../assets/images/stuffedbell.jpeg'), 
      Description:
        "\nThese stuffed bell peppers are filled with a savory mixture of rice, ground meat, and spices, making for a filling supper option.",
      Ingredients:
        "\n• 4 bell peppers (any color)\n• 1 cup cooked rice\n• 1 lb ground beef or turkey\n• 1 can diced tomatoes\n• 1 onion, chopped\n• 1 tsp garlic powder\n• 1 tsp Italian seasoning\n• Salt and pepper to taste\n• Shredded cheese for topping (optional)",
      Instructions:
        "\n1. Preheat the oven to 375°F (190°C).\n2. Cut the tops off the bell peppers and remove seeds.\n3. In a skillet, cook the ground meat and onion until browned. Stir in rice, tomatoes, garlic powder, Italian seasoning, salt, and pepper.\n4. Fill each bell pepper with the mixture and place in a baking dish.\n5. Bake for 25-30 minutes. If desired, top with shredded cheese and bake for an additional 5 minutes until melted.",
    },
    {
      id: "4",
      title: "vegetablecurry",
      image: require('../assets/images/vegetablecurry.jpeg'), 
      Description:
        "\nA vibrant vegetable curry made with a mix of seasonal vegetables and aromatic spices. Serve it with rice or naan for a satisfying supper.",
      Ingredients:
        "\n• 2 cups mixed vegetables (cauliflower, peas, carrots, etc.)\n• 1 onion, chopped\n• 2 cloves garlic, minced\n• 1 inch ginger, grated\n• 1 can coconut milk\n• 2 tbsp curry powder\n• Salt to taste\n• 2 tbsp vegetable oil\n• Fresh cilantro for garnish (optional)",
      Instructions:
        "\n1. Heat vegetable oil in a pot over medium heat. Add onion, garlic, and ginger; sauté until softened.\n2. Stir in curry powder and cook for 1 minute.\n3. Add mixed vegetables and coconut milk, bring to a simmer.\n4. Cook for 15-20 minutes until vegetables are tender.\n5. Season with salt and garnish with fresh cilantro before serving.",
    },
  ];
  
  
  
  const Supper = () => {
    const [modalVisible, setModalVisible] = useState(false);
    const [selectedItems, setSelectedItems] = useState(null);
  
    const renderItem = ({ item }) => (
      <Pressable
        style={styles.card}
        onPress={() => {
          setSelectedItems(item);
          setModalVisible(true);
        }}
      >
        <Image source={item.image} style={styles.image} />
        <Text style={styles.cardTitle}>{item.title}</Text>
      </Pressable>
    );
  
    const closeModal = () => {
      setModalVisible(false);
      setSelectedItems(null);
    };
  
    return (
      <GestureHandlerRootView style={{ flex: 1, backgroundColor:'black' }}>
        <Text style={styles.text}>Lunch</Text>
        <FlatList
        style={{marginTop: 30}}
          data={data}
          renderItem={renderItem}
          keyExtractor={(item) => item.id}
          numColumns={2}
          columnWrapperStyle={styles.row}
        />
        <Modal
          visible={modalVisible}
          animationType="slide"
          onRequestClose={closeModal}
        >
          <View style={styles.modalContainer}>
            {selectedItems && (
              <>
                <Text style={styles.modalTitle}>{selectedItems.title}</Text>
                <Text style={styles.modalDescription}>
                  {selectedItems.Description}
                </Text>
                <Text style={styles.modalIngredients}>
                  Ingredients:{selectedItems.Ingredients}
                </Text>
                <Text style={styles.modalInstructions}>
                  Instructions:{selectedItems.Instructions}
                </Text>
                <TouchableOpacity style={styles.closeButton} onPress={closeModal}>
                  <Text style={styles.closeButtonText}>Close</Text>
                </TouchableOpacity>
              </>
            )}
          </View>
        </Modal>
      </GestureHandlerRootView>
    );
  };
  
  export default Supper;
  
  const styles = StyleSheet.create({
    text: {
      fontSize: 25,
      fontWeight: "bold",
      color: "white",
      textAlign: "center",
      marginTop: "10%",
    },
    row: {
      justifyContent: "space-between",
    },
    card: {
      height: 270,
      width: 170,
      backgroundColor: "#000000",
      borderWidth: 1,
      borderRadius: 10,
      borderColor: "grey",
      marginBottom: 20,
      alignItems: "center",
      justifyContent: "center",
      padding: 10,
      marginHorizontal: 5,
    },
    image: {
      width: "100%",
      height: 170,
      borderRadius: 10,
      marginBottom: 10,
    },
    cardTitle: {
      color: "white",
      fontSize: 18,
      fontWeight: "bold",
      textAlign: "center",
    },
    modalContainer: {
      flex: 1,
      backgroundColor: "white",
      padding: 20,
    },
    modalTitle: {
      fontSize: 24,
      fontWeight: "bold",
      marginBottom: 10,
    },
    modalDescription: {
      fontSize: 16,
      marginBottom: 10,
    },
    modalIngredients: {
      fontSize: 16,
      marginBottom: 10,
    },
    modalInstructions: {
      fontSize: 16,
      marginBottom: 20,
    },
    closeButton: {
      backgroundColor: "#FFA500",
      padding: 10,
      borderRadius: 5,
      alignItems: "center",
    },
    closeButtonText: {
      color: "white",
      fontWeight: "bold",
    },
  });
  