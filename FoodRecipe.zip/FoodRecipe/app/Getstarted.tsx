import { StyleSheet, Text, View, Image, TouchableOpacity } from 'react-native'
import React from 'react'
import { useNavigation } from 'expo-router';

const Getstarted = () => {
  const navigation = useNavigation(); 
  return (
    <View style={{flex: 1, backgroundColor: 'black' }}>
      <Text style={styles.getStartedText}>Get Started with Recipe Book</Text>
      <View>
        <Image
        style={styles.getStartedImage} 
        source={require('../assets/images/recipelogo.png')}
        />
      </View>
      <TouchableOpacity 
      style={styles.getStartedButton}
      onPress={()=> navigation.navigate('(tabs)', { screen: 'home' })}
      >
        <Text style={{fontSize: 15, fontWeight: 'bold'}}>Start</Text>
      </TouchableOpacity>
    </View> 
  )
}

export default Getstarted;

const styles = StyleSheet.create({
  getStartedText:{
    fontSize: 25,
    fontWeight: 'bold',
    textAlign: 'center',
    marginTop: '25%',
    color: '#FFA500'
  },
  getStartedImage:{
    width: 400,
    height: 400,
    alignSelf: 'center',
    resizeMode: 'contain',
    tintColor: '#FFA500',  
  },
  getStartedButton:{
    backgroundColor: '#FFA500',
    padding: 15,
    borderRadius: 30,
    marginTop: 30,
    alignSelf: 'center',
    width: '80%',
    justifyContent: 'center',
    alignItems: 'center',
    elevation: 5,

  }
})