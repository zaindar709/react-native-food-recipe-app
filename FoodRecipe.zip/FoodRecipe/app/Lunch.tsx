import {
    StyleSheet,
    Text,
    View,
    TouchableOpacity,
    Image,
    Modal,
    Dimensions,
    Pressable
  } from "react-native";
  import React, { useState } from "react";
  import { FlatList } from "react-native-gesture-handler";
  import { GestureHandlerRootView } from "react-native-gesture-handler"; 
  
  const data = [
    {
      id: "1",
      title: "Quinoa Salad with Chickpeas",
      image: require('../assets/images/quinoasalad.jpeg'), 
      Description:
        "This refreshing quinoa salad is loaded with protein and fiber from chickpeas and fresh vegetables. It's a perfect light lunch that's both filling and nutritious.",
      Ingredients:
        "\n• 1 cup cooked quinoa\n• 1 can chickpeas, drained and rinsed\n• 1 cup cherry tomatoes, halved\n• 1 cucumber, diced\n• 1/4 red onion, finely chopped\n• 1/4 cup parsley, chopped\n• Juice of 1 lemon\n• 2 tbsp olive oil\n• Salt and pepper to taste",
      Instructions:
        "\n1. In a large bowl, combine the cooked quinoa, chickpeas, cherry tomatoes, cucumber, red onion, and parsley.\n2. In a small bowl, whisk together lemon juice, olive oil, salt, and pepper.\n3. Pour the dressing over the salad and toss to combine.\n4. Serve chilled or at room temperature.",
    },
    {
      id: "2",
      title: "Grilled Chicken Wrap",
      image: require('../assets/images/grilledchicken.jpeg'), 
      Description:
        "A grilled chicken wrap filled with fresh veggies and a zesty sauce, making it a satisfying and easy-to-eat lunch option.",
      Ingredients:
        "\n• 1 large tortilla wrap\n• 1 grilled chicken breast, sliced\n• 1/2 avocado, sliced\n• 1 cup lettuce\n• 1/4 cup shredded cheese\n• 2 tbsp ranch dressing or your choice of sauce",
      Instructions:
        "\n1. Lay the tortilla flat and layer with grilled chicken, avocado, lettuce, cheese, and dressing.\n2. Roll the tortilla tightly and slice in half.\n3. Serve with your favorite chips or a side salad.",
    },
    {
      id: "3",
      title: "Veggie Stir-Fry",
      image: require('../assets/images/vegeistir.jpeg'), 
      Description:
        "A quick and colorful veggie stir-fry that’s perfect for lunch, loaded with your favorite vegetables and a savory sauce.",
      Ingredients:
        "\n• 2 cups mixed vegetables (broccoli, bell peppers, carrots, etc.)\n• 2 tbsp soy sauce\n• 1 tbsp sesame oil\n• 1 clove garlic, minced\n• 1 inch ginger, grated\n• Cooked rice or noodles for serving",
      Instructions:
        "\n1. Heat sesame oil in a pan over medium heat. Add garlic and ginger, sauté until fragrant.\n2. Add mixed vegetables and stir-fry for 5-7 minutes until tender-crisp.\n3. Stir in soy sauce and cook for an additional minute.\n4. Serve over cooked rice or noodles.",
    },
    {
      id: "4",
      title: "Caprese Sandwich",
      image: require('../assets/images/capreessandwitch.jpeg'), 
      Description:
        "A classic Caprese sandwich with fresh mozzarella, tomatoes, and basil, drizzled with balsamic glaze for a burst of flavor.",
      Ingredients:
        "\n• 1 ciabatta roll or baguette\n• 1 ball fresh mozzarella, sliced\n• 1 large tomato, sliced\n• Fresh basil leaves\n• Balsamic glaze\n• Salt and pepper to taste",
      Instructions:
        "\n1. Slice the ciabatta roll in half and layer with mozzarella, tomato slices, and fresh basil.\n2. Drizzle with balsamic glaze and season with salt and pepper.\n3. Close the sandwich and enjoy immediately or grill it for a warm, melty option.",
    },
  ];
  
  
  const Lunch = () => {
    const [modalVisible, setModalVisible] = useState(false);
    const [selectedItems, setSelectedItems] = useState(null);
  
    const renderItem = ({ item }) => (
      <Pressable
        style={styles.card}
        onPress={() => {
          setSelectedItems(item);
          setModalVisible(true);
        }}
      >
        <Image source={item.image} style={styles.image} />
        <Text style={styles.cardTitle}>{item.title}</Text>
      </Pressable>
    );
  
    const closeModal = () => {
      setModalVisible(false);
      setSelectedItems(null);
    };
  
    return (
      <GestureHandlerRootView style={{ flex: 1, backgroundColor:'black' }}>
        <Text style={styles.text}>Lunch</Text>
        <FlatList
        style={{marginTop: 30}}
          data={data}
          renderItem={renderItem}
          keyExtractor={(item) => item.id}
          numColumns={2}
          columnWrapperStyle={styles.row}
        />
        <Modal
          visible={modalVisible}
          animationType="slide"
          onRequestClose={closeModal}
        >
          <View style={styles.modalContainer}>
            {selectedItems && (
              <>
                <Text style={styles.modalTitle}>{selectedItems.title}</Text>
                <Text style={styles.modalDescription}>
                  {selectedItems.Description}
                </Text>
                <Text style={styles.modalIngredients}>
                  Ingredients:{selectedItems.Ingredients}
                </Text>
                <Text style={styles.modalInstructions}>
                  Instructions:\n{selectedItems.Instructions}
                </Text>
                <TouchableOpacity style={styles.closeButton} onPress={closeModal}>
                  <Text style={styles.closeButtonText}>Close</Text>
                </TouchableOpacity>
              </>
            )}
          </View>
        </Modal>
      </GestureHandlerRootView>
    );
  };
  
  export default Lunch;
  
  const styles = StyleSheet.create({
    text: {
      fontSize: 25,
      fontWeight: "bold",
      color: "white",
      textAlign: "center",
      marginTop: "10%",
    },
    row: {
      justifyContent: "space-between",
    },
    card: {
      height: 270,
      width: 170,
      backgroundColor: "#000000",
      borderWidth: 1,
      borderRadius: 10,
      borderColor: "grey",
      marginBottom: 20,
      alignItems: "center",
      justifyContent: "center",
      padding: 10,
      marginHorizontal: 5,
    },
    image: {
      width: "100%",
      height: 170,
      borderRadius: 10,
      marginBottom: 10,
    },
    cardTitle: {
      color: "white",
      fontSize: 18,
      fontWeight: "bold",
      textAlign: "center",
    },
    modalContainer: {
      flex: 1,
      backgroundColor: "white",
      padding: 20,
    },
    modalTitle: {
      fontSize: 24,
      fontWeight: "bold",
      marginBottom: 10,
    },
    modalDescription: {
      fontSize: 16,
      marginBottom: 10,
    },
    modalIngredients: {
      fontSize: 16,
      marginBottom: 10,
    },
    modalInstructions: {
      fontSize: 16,
      marginBottom: 20,
    },
    closeButton: {
      backgroundColor: "#FFA500",
      padding: 10,
      borderRadius: 5,
      alignItems: "center",
    },
    closeButtonText: {
      color: "white",
      fontWeight: "bold",
    },
  });
  