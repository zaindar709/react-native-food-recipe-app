// app/MainStack.tsx
import React from 'react';
import { createStackNavigator } from '@react-navigation/stack';
// import SignIn from './SignIn';
import TabsLayout from './(tabs)/_layout';
import Getstarted from './Getstarted';
import Cooked from './Cooked';
import Breakfast from './Breakfast';
import Lunch from './Lunch';
import Dinner from './Dinner';
import AppetizersList from './AppetizersList';
import SaladsList from './SaladsList';
import MainDishes from './MainDishes';
import SoupsList from './SoupsList';


const Stack = createStackNavigator();

const MainStack = () => {
  return (
    <Stack.Navigator initialRouteName="Getstarted">

      <Stack.Screen name="Getstarted" component={Getstarted} options={{ headerShown: false }} />
      <Stack.Screen name="tabs" component={TabsLayout} options={{ headerShown: false }} />
      <Stack.Screen name="Cooked" component={Cooked} options={{ headerShown: false }} />
      <Stack.Screen name="Breakfast" component={Breakfast} options={{ headerShown: false }} />
      <Stack.Screen name="Lunch" component={Lunch} options={{ headerShown: false }} />
      <Stack.Screen name = "Dinner" component={Dinner} options={{ headerShown: false }} />
      <Stack.Screen name = "AppetizersList" component={AppetizersList} options={{ headerShown: false }}/>
      <Stack.Screen name="SaladsList" component={SaladsList} options={{ headerShown: false }} />
      <Stack.Screen name="MainDishes" component={MainDishes} options={{ headerShown: false }}/>
      <Stack.Screen name="SoupsList" component={SoupsList} options={{ headerShown: false }}/>

    </Stack.Navigator>
  );
};

export default MainStack;
