import {
    StyleSheet,
    Text,
    View,
    TouchableOpacity,
    Image,
    Modal,
    Dimensions,
    Pressable
  } from "react-native";
  import React, { useState } from "react";
  import { FlatList } from "react-native-gesture-handler";
  import { GestureHandlerRootView } from "react-native-gesture-handler"; 
  
  const data = [
    {
      id: "1",
      title: "Oatmeal with nuts and fruit",
      image: require('../assets/images/oatmeals.jpeg'),
      Description:
        "This warm and wholesome oatmeal bowl is a nutritious breakfast option, packed with fiber, healthy fats, and natural sweetness from fruits. It’s quick to make and can be customized with your favorite nuts, fruits, and additional toppings.",
      Ingredients:
        "\n• 1 cup rolled oats\n• 2 cups water or milk\n• 1/2 tsp cinnamon (optional)\n• 1 tbsp honey or maple syrup (optional)\n• 1/4 cup mixed nuts\n• 1/4 cup fresh or dried fruits\n• Pinch of salt",
      Instructions:
        "\n• Boil water or milk, add oats and salt.\n• Simmer for 5-7 mins, stirring occasionally.\n• Add cinnamon and sweetener if desired.\n• Top with nuts and fruits. Enjoy!",
    },
    {
      id: "2",
      title: "Protein Pancakes",
      image: require('../assets/images/pancake.jpeg'),
      Description:
        "These protein pancakes are a fluffy, satisfying breakfast option loaded with protein. They're perfect for a quick and healthy start to the day and can be topped with your favorite fruits and syrup.",
      Ingredients:
        "\n• 1 cup oats\n• 1 scoop protein powder (vanilla or plain)\n• 1/2 cup cottage cheese or Greek yogurt\n• 2 large eggs\n• 1/4 cup milk (dairy or plant-based)\n• 1/2 tsp baking powder\n• 1/2 tsp vanilla extract (optional)\n• Pinch of salt",
      Instructions:
        "\n1. Blend oats to a fine flour in a blender.\n2. Add protein powder, cottage cheese, eggs, milk, baking powder, vanilla, and salt.\n3. Blend until smooth.\n4. Heat a non-stick skillet over medium heat and lightly grease.\n5. Pour small amounts of batter to form pancakes.\n6. Cook until bubbles form, flip, and cook until golden brown.\n7. Serve with fruits or syrup as desired.",
    },
    {
      id: "3",
      title: "Fruit Smoothie",
      image: require('../assets/images/smotthie.jpeg'),
      Description:
        "This refreshing fruit smoothie is a quick, nutrient-rich option that's perfect for breakfast or a snack. Customize it with your favorite fruits for a burst of flavor and vitamins.",
      Ingredients:
        "\n• 1 cup frozen mixed berries (or your choice of fruit)\n• 1/2 banana\n• 1/2 cup Greek yogurt or plant-based yogurt\n• 1/2 cup milk (dairy or plant-based)\n• 1 tbsp honey or maple syrup (optional)\n• 1 tbsp chia seeds or flaxseeds (optional)",
      Instructions:
        "\n1. Add the berries, banana, yogurt, and milk to a blender.\n2. Blend until smooth and creamy.\n3. Add honey for sweetness if desired.\n4. Pour into a glass and top with chia seeds if desired.\n5. Enjoy immediately!",
    },
    {
      id: "4",
      title: "French Toast",
      image: require('../assets/images/frenchtoast.jpeg'),
      Description:
        "This classic French toast recipe features bread soaked in a rich custard mixture and cooked until golden brown. It's a delicious and indulgent breakfast option, perfect for a leisurely weekend brunch.",
      Ingredients:
        "\n• 4 slices of bread (thick-cut)\n• 2 large eggs\n• 1/2 cup milk (dairy or plant-based)\n• 1 tsp vanilla extract\n• 1/2 tsp ground cinnamon\n• Pinch of salt\n• Butter or oil for cooking\n• Maple syrup and powdered sugar for serving (optional)",
      Instructions:
        "\n1. In a bowl, whisk together eggs, milk, vanilla, cinnamon, and salt.\n2. Heat a non-stick skillet over medium heat and add butter or oil.\n3. Dip each slice of bread in the egg mixture, allowing it to soak briefly.\n4. Cook each slice in the skillet until golden brown on both sides.\n5. Serve warm with maple syrup and a dusting of powdered sugar if desired.",
    },
  ];
  
  const Breakfast = () => {
    const [modalVisible, setModalVisible] = useState(false);
    const [selectedItems, setSelectedItems] = useState(null);
  
    const renderItem = ({ item }) => (
      <Pressable
        style={styles.card}
        onPress={() => {
          setSelectedItems(item);
          setModalVisible(true);
        }}
      >
        <Image source={item.image} style={styles.image} />
        <Text style={styles.cardTitle}>{item.title}</Text>
      </Pressable>
    );
  
    const closeModal = () => {
      setModalVisible(false);
      setSelectedItems(null);
    };
  
    return (
      <GestureHandlerRootView style={{ flex: 1, backgroundColor:'black' }}>
        <Text style={styles.text}>Breakfast</Text>
        <FlatList
        style={{marginTop: 30}}
          data={data}
          renderItem={renderItem}
          keyExtractor={(item) => item.id}
          numColumns={2}
          columnWrapperStyle={styles.row}
        />
        <Modal
          visible={modalVisible}
          animationType="slide"
          onRequestClose={closeModal}
        >
          <View style={styles.modalContainer}>
            {selectedItems && (
              <>
                <Text style={styles.modalTitle}>{selectedItems.title}</Text>
                <Text style={styles.modalDescription}>
                  {selectedItems.Description}
                </Text>
                <Text style={styles.modalIngredients}>
                  Ingredients:{selectedItems.Ingredients}
                </Text>
                <Text style={styles.modalInstructions}>
                  Instructions:{selectedItems.Instructions}
                </Text>
                <TouchableOpacity style={styles.closeButton} onPress={closeModal}>
                  <Text style={styles.closeButtonText}>Close</Text>
                </TouchableOpacity>
              </>
            )}
          </View>
        </Modal>
      </GestureHandlerRootView>
    );
  };
  
  export default Breakfast;
  
  const styles = StyleSheet.create({
    text: {
      fontSize: 25,
      fontWeight: "bold",
      color: "white",
      textAlign: "center",
      marginTop: "10%",
    },
    row: {
      justifyContent: "space-between",
    },
    card: {
      height: 270,
      width: 170,
      backgroundColor: "#000000",
      borderWidth: 1,
      borderRadius: 10,
      borderColor: "grey",
      marginBottom: 20,
      alignItems: "center",
      justifyContent: "center",
      padding: 10,
      marginHorizontal: 5,
    },
    image: {
      width: "100%",
      height: 170,
      borderRadius: 10,
      marginBottom: 10,
    },
    cardTitle: {
      color: "white",
      fontSize: 18,
      fontWeight: "bold",
      textAlign: "center",
    },
    modalContainer: {
      flex: 1,
      backgroundColor: "white",
      padding: 20,
    },
    modalTitle: {
      fontSize: 24,
      fontWeight: "bold",
      marginBottom: 10,
    },
    modalDescription: {
      fontSize: 16,
      marginBottom: 10,
    },
    modalIngredients: {
      fontSize: 16,
      marginBottom: 10,
    },
    modalInstructions: {
      fontSize: 16,
      marginBottom: 20,
    },
    closeButton: {
      backgroundColor: "#FFA500",
      padding: 10,
      borderRadius: 5,
      alignItems: "center",
    },
    closeButtonText: {
      color: "white",
      fontWeight: "bold",
    },
  });
  