import React, { useState } from "react";
import {
  StyleSheet,
  Text,
  View,
  TouchableOpacity,
  Image,
  Modal,
  Dimensions,
  Pressable,
} from "react-native";
import { FlatList } from "react-native-gesture-handler";
import { GestureHandlerRootView } from "react-native-gesture-handler";
import { WebView } from "react-native-webview";

const data = [
  {
    id: "1",
    title: "Samosas",
    image: require("../assets/images/Samosas.jpeg"),
    Description:
      "\nCrispy, deep-fried pastries filled with spiced potatoes and peas.",
    Ingredients:
      "\n• 2 cups all-purpose flour\n• 1 cup boiled potatoes\n• 1/2 cup green peas\n• Spices: cumin, coriander, garam masala\n• Salt to taste\n• Oil for frying",
    Instructions:
      "\n1. Prepare the dough using flour and water.\n2. Make the filling with boiled potatoes, peas, and spices.\n3. Roll out dough, fill with mixture, and fold into a triangle shape.\n4. Deep fry until golden brown.",
    videoUri: "https://www.youtube.com/embed/RWWkES72DRQ",
  },
  {
    id: "2",
    title: "Pakoras",
    image: require("../assets/images/Pakoras.jpeg"),
    Description:
      "\nDeep-fried vegetables, often served with a spicy dipping sauce.",
    Ingredients:
      "\n• 1 cup chickpea flour (besan)\n• 1 cup mixed vegetables (potatoes, onions, spinach)\n• Spices: turmeric, chili powder, cumin\n• Water to make batter\n• Oil for frying",
    Instructions:
      "\n1. Mix chickpea flour with spices and water to form a batter.\n2. Dip vegetables into the batter.\n3. Deep fry until crispy and golden brown.\n4. Serve with mint chutney or ketchup.",
    videoUri: "https://www.youtube.com/embed/ref4lsPJ_r4",
  },
  {
    id: "3",
    title: "Dahi Bhalle",
    image: require("../assets/images/DahiBhalle.jpeg"),
    Description: "\nCrispy fried lentil balls soaked in a yogurt-based sauce.",
    Ingredients:
      "\n• 1 cup urad dal (split black gram)\n• 2 cups yogurt\n• Tamarind chutney\n• Spices: cumin powder, chili powder, chaat masala\n• Fresh coriander for garnish",
    Instructions:
      "\n1. Soak urad dal overnight and grind to a smooth paste.\n2. Fry small balls of the batter until golden.\n3. Soak the fried balls in warm water for 10 minutes.\n4. Serve in yogurt topped with chutney and spices.",
    videoUri: "https://www.youtube.com/embed/uza38L9DRFs",
  },
  {
    id: "4",
    title: "Shami Kebabs",
    image: require("../assets/images/ShamiKebab.jpeg"),
    Description: "\nMinced meat kebabs, often served with naan or roti.",
    Ingredients:
      "\n• 500g minced meat (beef/lamb)\n• 1/2 cup chana dal (split chickpeas)\n• Onions, green chilies, ginger-garlic paste\n• Spices: garam masala, cumin, coriander\n• Oil for frying",
    Instructions:
      "\n1. Cook minced meat and chana dal with spices until tender.\n2. Blend the mixture into a smooth paste.\n3. Shape into patties and shallow fry until browned.\n4. Serve hot with naan or roti.",
    videoUri: "https://www.youtube.com/embed/PWN-RvjQnUE",
  },
  {
    id: "5",
    title: "Chicken Tikka",
    image: require("../assets/images/ChickenTikka.jpeg"),
    Description: "\nGrilled chicken pieces marinated in yogurt and spices.",
    Ingredients:
      "\n• 500g boneless chicken\n• 1 cup yogurt\n• Spices: paprika, garam masala, cumin, garlic\n• Lemon juice\n• Skewers",
    Instructions:
      "\n1. Marinate chicken pieces in yogurt and spices for at least 2 hours.\n2. Thread onto skewers and grill until cooked through.\n3. Serve with onions and lemon wedges.",
    videoUri: "https://www.youtube.com/embed/5EAgEwjHaSk",
  },
  {
    id: "6",
    title: "Spring Rolls",
    image: require("../assets/images/SpringRolls.jpeg"),
    Iescription: "\nGrilled chicken pieces marinated in yogurt and spices.",
    Ingredients:
      "\n• 500g boneless chicken\n• 1 cup yogurt\n• Spices: paprika, garam masala, cumin, garlic\n• Lemon juice\n• Skewers",
    Instructions:
      "\n1. Marinate chicken pieces in yogurt and spices for at least 2 hours.\n2. Thread onto skewers and grill until cooked through.\n3. Serve with onions and lemon wedges.",
    videoUri: "https://www.youtube.com/embed/M328g44dEtE",
  },
];

const AppetizersList = () => {
  const [modalVisible, setModalVisible] = useState(false);
  const [selectedItem, setSelectedItem] = useState(null);
  const [showVideo, setShowVideo] = useState(false);

  const renderItem = ({ item }) => (
    <Pressable
      style={styles.card}
      onPress={() => {
        setSelectedItem(item);
        setShowVideo(false);
        setModalVisible(true);
      }}
    >
      <Image source={item.image} style={styles.image} />
      <Text style={styles.cardTitle}>{item.title}</Text>
      <View style={styles.optionButtons}>
        <TouchableOpacity
          onPress={() => {
            setSelectedItem(item);
            setShowVideo(false);
            setModalVisible(true);
          }}
        >
          <Text style={styles.optionText}>Read</Text>
        </TouchableOpacity>
        <TouchableOpacity
          onPress={() => {
            setSelectedItem(item);
            setShowVideo(true);
            setModalVisible(true);
          }}
        >
          <Text style={styles.optionText}>Watch</Text>
        </TouchableOpacity>
      </View>
    </Pressable>
  );

  const closeModal = () => {
    setModalVisible(false);
    setSelectedItem(null);
  };

  return (
    <GestureHandlerRootView style={{ flex: 1, backgroundColor: "black" }}>
      <Text style={styles.text}>Appetizers List</Text>
      <FlatList
        style={{ marginTop: 30 }}
        data={data}
        renderItem={renderItem}
        keyExtractor={(item) => item.id}
        numColumns={2}
        columnWrapperStyle={styles.row}
      />
      <Modal
        visible={modalVisible}
        animationType="slide"
        onRequestClose={closeModal}
      >
        <View style={styles.modalContainer}>
          {selectedItem && (
            <>
              <Text style={styles.modalTitle}>{selectedItem.title}</Text>
              {showVideo ? (
                 <WebView
                 source={{ uri: selectedItem.videoUri }} 
                 style={styles.video}
                 javaScriptEnabled={true} 
                 domStorageEnabled={true} 
                 allowsFullscreenVideo={true}
               />
              ) : (
                <>
                  <Text style={styles.modalDescription}>
                    {selectedItem.Description}
                  </Text>
                  <Text style={styles.modalIngredients}>
                    Ingredients: {selectedItem.Ingredients}
                  </Text>
                  <Text style={styles.modalInstructions}>
                    Instructions: {selectedItem.Instructions}
                  </Text>
                </>
              )}
              <TouchableOpacity style={styles.closeButton} onPress={closeModal}>
                <Text style={styles.closeButtonText}>Close</Text>
              </TouchableOpacity>
            </>
          )}
        </View>
      </Modal>
    </GestureHandlerRootView>
  );
};

export default AppetizersList;

const styles = StyleSheet.create({
  text: {
    fontSize: 25,
    fontWeight: "bold",
    color: "white",
    textAlign: "center",
    marginTop: "10%",
  },
  row: {
    justifyContent: "space-between",
  },
  card: {
    height: 270,
    width: 170,
    backgroundColor: "#333333",
    borderWidth: 1,
    borderRadius: 10,
    borderColor: "grey",
    marginBottom: 20,
    alignItems: "center",
    justifyContent: "center",
    padding: 10,
    marginHorizontal: 5,
  },
  image: {
    width: "100%",
    height: 170,
    borderRadius: 10,
    marginBottom: 10,
  },
  cardTitle: {
    color: "white",
    fontSize: 18,
    fontWeight: "bold",
    textAlign: "center",
  },
  optionButtons: {
    flexDirection: "row",
    justifyContent: "space-between",
    width: "100%",
    marginTop: 10,
  },
  optionText: {
    color: "orange",
    fontWeight: "bold",
    fontSize: 16,
  },
  modalContainer: {
    flex: 1,
    backgroundColor: "white",
    padding: 20,
  },
  modalTitle: {
    fontSize: 24,
    fontWeight: "bold",
    color: "#333",
    marginBottom: 10,
  },
  modalDescription: {
    fontSize: 16,
    color: "#333",
    marginBottom: 10,
    lineHeight: 22,
  },
  modalIngredients: {
    fontSize: 16,
    color: "#333",
    marginBottom: 10,
    lineHeight: 22,
  },
  modalInstructions: {
    fontSize: 16,
    color: "#333",
    marginBottom: 20,
    lineHeight: 22,
  },
  video: {
    height: '50%',
    width: Dimensions.get("window").width - 40,
    borderRadius: 10,
    alignSelf: "center",
  },
  closeButton: {
    backgroundColor: "#FFA500",
    padding: 10,
    borderRadius: 5,
    alignItems: "center",
    marginTop: 20,
  },
  closeButtonText: {
    color: "white",
    fontWeight: "bold",
    fontSize: 16,
  },
});
