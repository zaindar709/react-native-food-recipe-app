import React, { useState } from "react";
import {
  View,
  Text,
  TouchableOpacity,
  FlatList,
  Image,
  StyleSheet,
} from "react-native";
import { useNavigation } from "@react-navigation/native";

const Favorites = () => {
  const navigation = useNavigation();

  const [activeTab, setActiveTab] = useState("Favorites");

  const navigateToScreen = (screen) => {
    if (screen === "Cooked") {
      navigation.navigate("Cooked"); // Navigate to the Cooked screen
    }
  };

  const renderCard = ({ item }) => (
    <View style={styles.card}>
      <Image source={item.image} style={styles.image} />
      <Text style={styles.title}>{item.title}</Text>
      <Text style={styles.description}>{item.description}</Text>
      <View style={styles.footer}>
        <Text style={styles.rating}>⭐ 4.8</Text>
        <Text style={styles.views}>👥 9</Text>
        <Text style={styles.heart}>❤️</Text>
      </View>
    </View>
  );

  const data = [
    {
      id: "1",
      title: "Crispy Fried Chicken",
      description: "chicken 1 kilo, garlic clove 4, ginger...",
      image: require("../../assets/images/appetizer.png"), // replace with actual image path
    },
  ];

  return (
    <View style={styles.container}>
      <View style={styles.tabsContainer}>
        <TouchableOpacity
          style={[styles.tab, activeTab === "Favorites" && styles.activeTab]}
          onPress={() => setActiveTab("Favorites")}
        >
          <Text
            style={[
              styles.tabText,
              activeTab === "Favorites" && styles.activeTabText,
            ]}
          >
            Favorites
          </Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[styles.tab, activeTab === "Cooked" && styles.activeTab]}
          onPress={() => navigateToScreen("Cooked")}
        >
          <Text
            style={[
              styles.tabText,
              activeTab === "Cooked" && styles.activeTabText,
            ]}
          >
            Cooked
          </Text>
        </TouchableOpacity>
      </View>

      <FlatList
        data={data}
        renderItem={renderCard}
        keyExtractor={(item) => item.id}
        contentContainerStyle={styles.cardList}
      />
    </View>
  );
};

export default Favorites;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#333",
    paddingTop: 20,
  },
  tabsContainer: {
    flexDirection: "row",
    justifyContent: "space-around",
    marginBottom: 10,
  },
  tab: {
    paddingBottom: 8,
  },
  activeTab: {
    borderBottomWidth: 2,
    borderBottomColor: "skyblue",
  },
  tabText: {
    color: "grey",
    fontSize: 16,
  },
  activeTabText: {
    color: "skyblue",
    fontWeight: "bold",
  },
  cardList: {
    paddingHorizontal: 16,
  },
  card: {
    backgroundColor: "#222",
    borderRadius: 8,
    marginBottom: 20,
    padding: 10,
    width: "100%",
  },
  image: {
    width: "100%",
    height: 150,
    borderRadius: 8,
  },
  title: {
    color: "#fff",
    fontSize: 18,
    fontWeight: "bold",
    marginTop: 10,
  },
  description: {
    color: "#ccc",
    fontSize: 14,
    marginVertical: 5,
  },
  footer: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },
  rating: {
    color: "gold",
  },
  views: {
    color: "grey",
  },
  heart: {
    color: "red",
  },
});
