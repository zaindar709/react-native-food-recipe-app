import { StyleSheet, Text, View, Dimensions, FlatList } from "react-native";
import React from "react";
import { Video, ResizeMode} from "expo-av";
import { WebView } from "react-native-webview";
import { useSafeAreaInsets } from "react-native-safe-area-context";

const { height, width } = Dimensions.get("window");

const videos = [
  {
    id: "1",
    url: "https://youtube.com/shorts/JglJ2OYbjq0?si=xNyYX61v-cFyyq0g",
    isYouTube: true,
  },
  {
    id: "1",
    url: "https://youtube.com/shorts/JglJ2OYbjq0?si=xNyYX61v-cFyyq0g",
    isYouTube: true,
  },
  {
    id: "1",
    url: "https://youtube.com/shorts/JglJ2OYbjq0?si=xNyYX61v-cFyyq0g",
    isYouTube: true,
  },
];

const Reels = () => {
  const insets = useSafeAreaInsets();
  const videoHeight = height - insets.bottom;

  const renderItem = ({ item }) => (
    <View style={[styles.videoContainer, { height: videoHeight }]}>
      {item.isYouTube ? (
        <WebView
          source={{ uri: item.url }}
          style={styles.video}
          javaScriptEnabled
          domStorageEnabled
          allowsInlineMediaPlayback
        />
      ) : (
        <Video
          source={{ uri: item.url }}
          style={styles.video}
          resizeMode={ResizeMode.COVER}
          isLooping
          shouldPlay
        />
      )}
    </View>
  );
  return (
    <View style={{ flex: 1 }}>
      <FlatList
        data={videos}
        keyExtractor={(item) => item.id}
        renderItem={renderItem}
        pagingEnabled
      />
    </View>
  );
};

export default Reels;

const styles = StyleSheet.create({
  videoContainer: {
    flex: 1,
    width: width,
    justifyContent: "center",
    alignItems: "center",
  },
  video: {
    width: width,
    height: "100%",
  },
});
