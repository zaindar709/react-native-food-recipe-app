import React, { useState } from "react";
import {
  View,
  Text,
  Modal,
  TextInput,
  Button,
  StyleSheet,
  TouchableOpacity,
  Image
} from "react-native";
import { FontAwesome } from "@expo/vector-icons";
import { GoogleSignin } from '@react-native-google-signin/google-signin';
import auth from '@react-native-firebase/auth';

const Profiles = () => {

  useEffect(() => {
    // Configure Google Sign-In
    GoogleSignin.configure({
      webClientId: '1026959595209-amo6cp8vevklntpkin2hfbrqnofpk4fb.apps.googleusercontent.com', // From Firebase
    });
  }, []);

  const onGoogleButtonPress = async () => {
    try {
      // Get the user's Google account information
      await GoogleSignin.hasPlayServices();
      const userInfo = await GoogleSignin.signIn();

      // Get the Google ID token and create a Firebase credential
      const googleCredential = auth.GoogleAuthProvider.credential(userInfo.idToken);

      // Sign in with the credential to Firebase
      await auth().signInWithCredential(googleCredential);
      console.log('User signed in with Google!');
    } catch (error) {
      console.error(error);
    }
  };

  const [modalVisible, setModalVisible] = useState(false);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [username, setUsername] = useState("");
  const [isRegistering, setIsRegistering] = useState(false);

  const handleSignIn = () => {
    console.log("Email:", email, "Password:", password);
    setModalVisible(false);
  };

  const handleRegister = () => {
    console.log("Username:", username, "Email:", email, "Password:", password);
    setModalVisible(false);
  };

  const handleModalOpen = (isRegistration) => {
    setEmail('');
    setPassword('');
    setUsername('');
    setIsRegistering(isRegistration);
    setModalVisible(true);
  };

  return (
    <View style={styles.container}>
      <View>
        <Image
          source={require('../../assets/images/research.png')}
          style={styles.researchImage}
        />
        <Text style={styles.researchText}>Discover additional opportunities for yourself</Text>
      </View>

      {/* Sign In Text */}
      <TouchableOpacity onPress={() => handleModalOpen(false)} style={styles.signInTextContainer}>
        <FontAwesome name="envelope" size={20} color="skyblue" />
        <Text style={styles.signInText}>Sign in by Email</Text>
      </TouchableOpacity>

      <Text style={styles.enterText}>You can also enter using</Text>

      {/* Google Button */}
      <TouchableOpacity 
        style={styles.googleButton}
        onPress={onGoogleButtonPress}
      >
        <FontAwesome name="google" size={20} color="white" style={styles.googleIcon} />
        <Text style={styles.googleText}>Google</Text>
      </TouchableOpacity>

      <Text style={styles.firstText}>First time with us?</Text>

      {/* Registration Text */}
      <TouchableOpacity onPress={() => handleModalOpen(true)} style={styles.signInTextContainer}>
        <FontAwesome name="envelope" size={20} color="skyblue" />
        <Text style={styles.signInText}>Registration</Text>
      </TouchableOpacity>
      <Text style={styles.privacyText}>Privacy Policy</Text>

      {/* Modal for Sign-In or Registration */}
      <Modal visible={modalVisible} animationType="slide" transparent={true} onRequestClose={() => setModalVisible(false)}>
        <View style={styles.modalOverlay}>
          <View style={styles.modalContainer}>
            <TouchableOpacity onPress={() => setModalVisible(false)} style={styles.closeButton}>
              <FontAwesome name="times" size={20} color="black" />
            </TouchableOpacity>
            {isRegistering ? (
              <>
                <TextInput
                  style={styles.input}
                  placeholder="Username"
                  value={username}
                  onChangeText={setUsername}
                />
              </>
            ) : null}

            <TextInput
              style={styles.input}
              placeholder="Email"
              keyboardType="email-address"
              value={email}
              onChangeText={setEmail}
            />
            <TextInput
              style={styles.input}
              placeholder="Password"
              secureTextEntry
              value={password}
              onChangeText={setPassword}
            />

            <Button title={isRegistering ? "Register" : "Sign In"} onPress={isRegistering ? handleRegister : handleSignIn} />
          </View>
        </View>
      </Modal>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'black',
  },
  signInTextContainer: {
    flexDirection: "row",
    alignSelf: "center",
    paddingTop: '10%',
  },
  signInText: {
    marginLeft: 10,
    fontSize: 15,
    color: 'skyblue',
  },
  modalOverlay: {
    flex: 1,
    justifyContent: "flex-end",
    backgroundColor: "rgba(0, 0, 0, 0.5)",
  },
  modalContainer: {
    backgroundColor: "white",
    height: 250,
    padding: 20,
    justifyContent: "center",
    alignItems: "center",
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
  },
  input: {
    width: "80%",
    height: 40,
    borderColor: "gray",
    borderWidth: 1,
    borderRadius: 5,
    marginBottom: 15,
    paddingLeft: 10,
  },
  researchImage: {
    height: 100,
    width: 100,
    alignSelf: 'center',
    resizeMode: 'contain',
    marginTop: '30%',
  },
  researchText: {
    fontSize: 15,
    color: 'lightgrey',
    alignSelf: 'center',
    marginTop: '10%',
  },
  enterText: {
    color: 'lightgrey',
    fontSize: 15,
    alignSelf: 'center',
    marginTop: '6%',
  },
  closeButton: {
    position: 'absolute',
    top: 10,
    right: 10,
    zIndex: 1,
  },
  googleButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'grey',
    paddingVertical: 15,
    paddingHorizontal: 70,
    borderRadius: 25,
    width: '60%',
    marginTop: 20,
    alignSelf: 'center',
  },
  googleIcon: {
    marginRight: 10,
  },
  googleText: {
    color: 'white',
    fontSize: 16,
    fontWeight: 'bold',
  },
  firstText: {
    color: 'lightgrey',
    fontSize: 15,
    alignSelf: 'center',
    marginTop: '10%',
  },
  privacyText:{
    color: 'grey',
    fontSize: 12,
    alignSelf: 'center',
    marginTop: '5%',
  }
});

export default Profiles;
