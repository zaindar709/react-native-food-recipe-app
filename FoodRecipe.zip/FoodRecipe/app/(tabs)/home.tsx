import {
  View,
  Text,
  FlatList,
  Image,
  StyleSheet,
  Dimensions,
  TouchableOpacity,
  ScrollView,
} from "react-native";
import React from "react";
import { useNavigation } from "expo-router";
import CategoryList from "@/components/CategoryList";

const DATA = [
  {
    id: "1",
    title: "Breakfast",
    screen: "Breakfast",
    image: require("../../assets/images/Breakfast.png"),
  },
  {
    id: "2",
    title: "Lunch",
    screen: "Lunch",
    image: require("../../assets/images/lunch.png"),
  },
  {
    id: "3",
    title: "Dinner",
    screen: "Dinner",
    image: require("../../assets/images/dinner.png"),
  },
  {
    id: "4",
    title: "Supper",
    screen: "Supper",
    image: require("../../assets/images/supper.png"),
  },
];

const home = () => {
  const navigation = useNavigation();

  const renderItem = ({ item }) => (
    <TouchableOpacity
      style={styles.card}
      onPress={() => navigation.navigate(item.screen)}
    >
      <Image source={item.image} style={styles.image} />
      <Text style={styles.text}>{item.title}</Text>
    </TouchableOpacity>
  );
  return (
    <View style={styles.mainContainer}>
      <ScrollView style={{ flex: 1 }}>
        <Text style={styles.todayText}>What's on for today</Text>
        <View style={styles.cardContainer}>
          <FlatList
            data={DATA}
            horizontal
            renderItem={renderItem}
            keyExtractor={(item) => item.id}
            showsHorizontalScrollIndicator={false}
          />
        </View>
        <Text style={styles.dailyText}>Daily recipes</Text>
        <TouchableOpacity style={styles.dailycard}>
          <Image
            source={require("../../assets/images/chickenwings.png")}
            style={styles.dailyImage}
          />
          <Text style={styles.dailyCardText}>Chicken pot pie</Text>
          <Text style={styles.dailyCardTextDescription}>
            Deliciously crispy and tender, chicken wings are a classic comfort
            food perfect for any occasion.
          </Text>
          <View style={styles.footer}>
            <Text style={styles.rating}>⭐ 4.8</Text>
            <Text style={styles.views}>👥 9</Text>
            <Text style={styles.heart}>❤️</Text>
          </View>
        </TouchableOpacity>
        <Text style={styles.categoryText}>Cetegories</Text>
        <CategoryList />
      </ScrollView>
    </View>
  );
};

export default home;

const styles = StyleSheet.create({
  mainContainer: {
    flex: 1,
    backgroundColor: "black",
  },
  todayText: {
    fontSize: 25,
    fontWeight: "bold",
    color: "white",
    textAlign: "center",
    marginTop: "25%",
  },
  flatList: {
    paddingHorizontal: 10,
  },
  card: {
    width: Dimensions.get("window").width / 4 - 15,
    height: 100,
    backgroundColor: "#000000",
    borderWidth: 1,
    borderColor: "grey",
    borderRadius: 10,
    marginHorizontal: 5,
    alignItems: "center",
    padding: 10,
  },
  image: {
    width: 60,
    height: 60,
    borderRadius: 30,
    marginBottom: 5,
  },
  text: {
    fontSize: 12,
    fontWeight: "bold",
    color: "#fff",
  },
  cardContainer: {
    marginTop: 20,
    marginHorizontal: 10,
  },
  dailyText: {
    fontSize: 25,
    fontWeight: "bold",
    color: "white",
    marginTop: 20,
    textAlign: "center",
  },
  dailycard: {
    width: 250,
    height: 330,
    alignSelf: "center",
    borderWidth: 1,
    borderColor: "grey",
    borderRadius: 10,
    elevation: 5,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.8,
    shadowRadius: 2,
    flexDirection: "column",
    marginTop: 10,
  },
  dailyCardText: {
    fontSize: 18,
    fontWeight: "bold",
    color: "#fff",
    paddingHorizontal: 10,
  },
  dailyImage: {
    width: "100%",
    height: 200,
    marginBottom: 10,
    borderTopLeftRadius: 10,
    borderTopRightRadius: 10,
  },
  dailyCardTextDescription: {
    fontSize: 12,
    color: "#fff",
    paddingHorizontal: 10,
    paddingVertical: 5,
    marginBottom: 10,
    textAlign: "justify",
  },
  categoryText: {
    fontSize: 25,
    fontWeight: "bold",
    color: "white",
    marginTop: 20,
    textAlign: "center",
  },
  footer: {
    flexDirection: "row",
    alignItems: "center",
    
  },
  rating: {
    color: "gold",
    marginLeft: 10,
    fontSize: 15,
  },
  views: {
    color: "grey",
    marginLeft: 60,
    fontSize: 15,
  },
  heart: {
    color: "red",
    marginLeft: 80,
    fontSize: 15,
  },
});
