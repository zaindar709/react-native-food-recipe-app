import { StyleSheet, Text, View } from "react-native";
import React from "react";
import { Tabs } from "expo-router";
import home from "./home";
import FontAwesome from "@expo/vector-icons/FontAwesome";

const TabsLayout = () => {
  return (
    <Tabs 
    screenOptions={{
      headerShown: false,
      tabBarStyle: { backgroundColor: '#FFA500' },  
        tabBarActiveTintColor: '#fff',  
        tabBarInactiveTintColor: '#555',  
    }}
    >
      <Tabs.Screen
        options={{
          title: "Home",
          tabBarIcon: ({ color }) => (
            <FontAwesome size={28} name="home" color={color} />
          ),
        }}
        name="home"
      />
      <Tabs.Screen
      options={{
        title: "Favorites",
        tabBarIcon: ({ color }) => (
          <FontAwesome size={28} name="heart" color={color} />
        ),
      }}
      name="Favorites"
      />
      <Tabs.Screen
        options={{
          title: "Reels",
          tabBarIcon: ({ color }) => (
            <FontAwesome size={28} name="film" color={color} />
          ),
        }}
        name="Reels"
        />
        <Tabs.Screen
        options={{
          title: "Profiles",
          tabBarIcon: ({ color }) => (
            <FontAwesome size={28} name="user" color={color}/>
          ),
        }}
        name="Profiles"
        />
    </Tabs>
  );
};

export default TabsLayout;

const styles = StyleSheet.create({});
