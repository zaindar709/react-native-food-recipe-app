import React, { useState } from "react";
import {
  StyleSheet,
  Text,
  View,
  TouchableOpacity,
  Image,
  Modal,
  Dimensions,
  Pressable,
} from "react-native";
import { FlatList } from "react-native-gesture-handler";
import { GestureHandlerRootView } from "react-native-gesture-handler";
import { WebView } from "react-native-webview";

const { width, height } = Dimensions.get("window");
const data = [
    {
        id: "1",
        title: "Greek Salad",
        image: require("../assets/images/greeksald.jpeg"),
        Description:
          "\nA refreshing Mediterranean salad made with a combination of crunchy vegetables, tangy feta cheese, and Kalamata olives, all tossed in a flavorful olive oil dressing.",
        Ingredients:
          "\n• 2 cups cherry tomatoes, halved\n• 1 cucumber, diced\n• 1 red onion, thinly sliced\n• 1/2 cup Kalamata olives\n• 1/2 cup feta cheese, cubed\n• 2 tbsp olive oil\n• 1 tbsp red wine vinegar\n• 1 tsp dried oregano\n• Salt and pepper to taste",
        Instructions:
          "\n1. In a large bowl, combine the tomatoes, cucumber, onion, olives, and feta cheese.\n2. Drizzle with olive oil and red wine vinegar.\n3. Sprinkle with dried oregano, salt, and pepper.\n4. Toss gently to combine.\n5. Serve chilled or at room temperature.",
        videoUri: "https://www.youtube.com/embed/T6-sIofa_4E",
      },
      {
        id: "2",
        title: "Caesar Salad",
        image: require("../assets/images/ceasersalad.jpeg"),
        Description:
          "\nA classic Caesar salad with crisp romaine lettuce, crunchy croutons, and a creamy Caesar dressing, topped with freshly grated Parmesan cheese.",
        Ingredients:
          "\n• 4 cups romaine lettuce, chopped\n• 1 cup croutons\n• 1/4 cup Parmesan cheese, grated\n• 1/2 cup Caesar dressing\n• 1 tsp garlic powder\n• 1 tbsp lemon juice\n• Salt and pepper to taste",
        Instructions:
          "\n1. In a large bowl, toss together the romaine lettuce, croutons, and grated Parmesan cheese.\n2. Drizzle with Caesar dressing, lemon juice, and sprinkle with garlic powder.\n3. Toss everything together until the salad is well-coated.\n4. Season with salt and pepper to taste.\n5. Serve immediately as a side or main dish.",
        videoUri: "https://www.youtube.com/embed/IGlWE4AFQ5Q",
      }
      ,
      {
        id: "3",
        title: "Quinoa Salad",
        image: require("../assets/images/quinoasalad.jpeg"),
        Description:
          "\nA healthy and flavorful salad made with protein-packed quinoa, fresh vegetables, and a tangy lemon vinaigrette dressing. Perfect for a light lunch or as a side dish.",
        Ingredients:
          "\n• 1 cup quinoa\n• 2 cups water or vegetable broth\n• 1 cucumber, diced\n• 1 bell pepper, diced\n• 1/2 cup red onion, finely chopped\n• 1/2 cup cherry tomatoes, halved\n• 1/4 cup fresh parsley, chopped\n• 1/4 cup olive oil\n• 2 tbsp lemon juice\n• 1 tbsp red wine vinegar\n• Salt and pepper to taste",
        Instructions:
          "\n1. Rinse the quinoa under cold water and drain.\n2. In a medium saucepan, bring water or vegetable broth to a boil, add quinoa, and simmer for 15-20 minutes, or until the liquid is absorbed and quinoa is tender.\n3. Allow the quinoa to cool.\n4. In a large bowl, combine the cooked quinoa, cucumber, bell pepper, red onion, cherry tomatoes, and parsley.\n5. In a separate small bowl, whisk together olive oil, lemon juice, red wine vinegar, salt, and pepper.\n6. Pour the dressing over the quinoa mixture and toss to combine.\n7. Chill the salad in the refrigerator for 30 minutes before serving.",
        videoUri: "https://www.youtube.com/embed/uK4LibynqSk",
      }
      ,
      {
        id: "4",
        title: "Waldorf Salad",
        image: require("../assets/images/waldorfsalad.jpeg"),
        Description:
          "\nA classic salad made with crisp apples, grapes, celery, and walnuts, all tossed in a creamy mayonnaise dressing. A refreshing and crunchy salad perfect for any occasion.",
        Ingredients:
          "\n• 2 apples, cored and diced\n• 1 cup grapes, halved\n• 1 celery stalk, chopped\n• 1/2 cup walnuts, chopped\n• 1/4 cup mayonnaise\n• 1 tbsp lemon juice\n• 1 tsp honey (optional)\n• Salt and pepper to taste",
        Instructions:
          "\n1. In a large bowl, combine the apples, grapes, celery, and walnuts.\n2. In a small bowl, whisk together mayonnaise, lemon juice, honey (if using), salt, and pepper.\n3. Pour the dressing over the fruit and nuts mixture and toss gently to combine.\n4. Chill in the refrigerator for 20 minutes before serving. Serve cold.",
        videoUri: "https://www.youtube.com/embed/foTy--iKmQ0",
      }
      ,
      {
        id: "5",
        title: "Pasta Salad",
        image: require("../assets/images/pastasalad.jpeg"),
        Description:
          "\nA colorful and flavorful pasta salad made with cooked pasta, fresh vegetables, and a tangy dressing. A perfect dish for a light lunch or as a side dish for a picnic or barbecue.",
        Ingredients:
          "\n• 2 cups pasta (penne, rotini, or fusilli)\n• 1 cup cherry tomatoes, halved\n• 1 cucumber, diced\n• 1/2 red onion, finely chopped\n• 1/2 cup black olives, sliced\n• 1/4 cup feta cheese, crumbled\n• 1/4 cup olive oil\n• 2 tbsp red wine vinegar\n• 1 tsp dried oregano\n• Salt and pepper to taste",
        Instructions:
          "\n1. Cook the pasta according to the package instructions. Drain and rinse under cold water to cool.\n2. In a large bowl, combine the pasta, tomatoes, cucumber, red onion, olives, and feta cheese.\n3. In a small bowl, whisk together olive oil, red wine vinegar, oregano, salt, and pepper.\n4. Pour the dressing over the pasta mixture and toss to coat evenly.\n5. Chill in the refrigerator for 30 minutes before serving. Serve cold.",
        videoUri: "https://www.youtube.com/embed/QtYIAimp3TU",
      }
      ,
      {
        id: "6",
        title: "Asian Slaw Salad",
        image: require("../assets/images/asianslawsalad.jpeg"),
        Description:
          "\nA crunchy and refreshing salad made with cabbage, carrots, and a flavorful Asian-style dressing. Perfect for a light meal or as a side dish to complement your main course.",
        Ingredients:
          "\n• 2 cups shredded cabbage (green and red)\n• 1 cup shredded carrots\n• 1/2 cup sliced green onions\n• 1/4 cup sesame seeds\n• 1/4 cup sliced almonds\n• 2 tbsp soy sauce\n• 2 tbsp rice vinegar\n• 1 tbsp honey or sugar\n• 1 tbsp sesame oil\n• 1 tsp ginger, grated\n• 1 clove garlic, minced\n• Salt and pepper to taste",
        Instructions:
          "\n1. In a large bowl, combine the shredded cabbage, shredded carrots, and sliced green onions.\n2. In a small bowl, whisk together soy sauce, rice vinegar, honey, sesame oil, grated ginger, garlic, salt, and pepper to make the dressing.\n3. Pour the dressing over the slaw mixture and toss to coat evenly.\n4. Top with sesame seeds and sliced almonds.\n5. Refrigerate for at least 30 minutes before serving for the best flavor.",
        videoUri: "https://www.youtube.com/embed/zJt5pIICJlE",
      }
      ,
];

const SaladsList = () => {
  const [modalVisible, setModalVisible] = useState(false);
  const [selectedItem, setSelectedItem] = useState(null);
  const [showVideo, setShowVideo] = useState(false);

  const renderItem = ({ item }) => (
    <Pressable
      style={styles.card}
      onPress={() => {
        setSelectedItem(item);
        setShowVideo(false);
        setModalVisible(true);
      }}
    >
      <Image source={item.image} style={styles.image} />
      <Text style={styles.cardTitle}>{item.title}</Text>
      <View style={styles.optionButtons}>
        <TouchableOpacity
          onPress={() => {
            setSelectedItem(item);
            setShowVideo(false);
            setModalVisible(true);
          }}
        >
          <Text style={styles.optionText}>Read</Text>
        </TouchableOpacity>
        <TouchableOpacity
          onPress={() => {
            setSelectedItem(item);
            setShowVideo(true);
            setModalVisible(true);
          }}
        >
          <Text style={styles.optionText}>Watch</Text>
        </TouchableOpacity>
      </View>
    </Pressable>
  );

  const closeModal = () => {
    setModalVisible(false);
    setSelectedItem(null);
  };

  return (
    <GestureHandlerRootView style={{ flex: 1, backgroundColor: "black" }}>
      <Text style={styles.text}>Salads List</Text>
      <FlatList
        style={{ marginTop: 30 }}
        data={data}
        renderItem={renderItem}
        keyExtractor={(item) => item.id}
        numColumns={2}
        columnWrapperStyle={styles.row}
      />
      <Modal
        visible={modalVisible}
        animationType="slide"
        onRequestClose={closeModal}
      >
        <View style={styles.modalContainer}>
          {selectedItem && (
            <>
              <Text style={styles.modalTitle}>{selectedItem.title}</Text>
              {showVideo ? (
                 <WebView
                 source={{ uri: selectedItem.videoUri }} 
                 style={styles.video}
                 javaScriptEnabled={true} 
                 domStorageEnabled={true} 
                 allowsFullscreenVideo={true}
               />
              ) : (
                <>
                  <Text style={styles.modalDescription}>
                    {selectedItem.Description}
                  </Text>
                  <Text style={styles.modalIngredients}>
                    Ingredients: {selectedItem.Ingredients}
                  </Text>
                  <Text style={styles.modalInstructions}>
                    Instructions: {selectedItem.Instructions}
                  </Text>
                </>
              )}
              <TouchableOpacity style={styles.closeButton} onPress={closeModal}>
                <Text style={styles.closeButtonText}>Close</Text>
              </TouchableOpacity>
            </>
          )}
        </View>
      </Modal>
    </GestureHandlerRootView>
  );
};

export default SaladsList;

const styles = StyleSheet.create({
  text: {
    fontSize: 25,
    fontWeight: "bold",
    color: "white",
    textAlign: "center",
    marginTop: "10%",
  },
  row: {
    justifyContent: "space-between",
  },
  card: {
    height: 270,
    width: 170,
    backgroundColor: "#333333",
    borderWidth: 1,
    borderRadius: 10,
    borderColor: "grey",
    marginBottom: 20,
    alignItems: "center",
    justifyContent: "center",
    padding: 10,
    marginHorizontal: 5,
  },
  image: {
    width: "100%",
    height: 170,
    borderRadius: 10,
    marginBottom: 10,
  },
  cardTitle: {
    color: "white",
    fontSize: 18,
    fontWeight: "bold",
    textAlign: "center",
  },
  optionButtons: {
    flexDirection: "row",
    justifyContent: "space-between",
    width: "100%",
    marginTop: 10,
  },
  optionText: {
    color: "orange",
    fontWeight: "bold",
    fontSize: 16,
  },
  modalContainer: {
    flex: 1,
    backgroundColor: "white",
    padding: 20,
  },
  modalTitle: {
    fontSize: 24,
    fontWeight: "bold",
    color: "#333",
    marginBottom: 10,
  },
  modalDescription: {
    fontSize: 16,
    color: "#333",
    marginBottom: 10,
    lineHeight: 22,
  },
  modalIngredients: {
    fontSize: 16,
    color: "#333",
    marginBottom: 10,
    lineHeight: 22,
  },
  modalInstructions: {
    fontSize: 16,
    color: "#333",
    marginBottom: 20,
    lineHeight: 22,
  },
  video: {
    // height: height * 0.2, 
    width: width * 0.9,
    borderRadius: 10,
    alignSelf: "center",
  },
  closeButton: {
    backgroundColor: "#FFA500",
    padding: 10,
    borderRadius: 5,
    alignItems: "center",
    marginTop: 20,
  },
  closeButtonText: {
    color: "white",
    fontWeight: "bold",
    fontSize: 16,
  },
  webview:{
    flex: 1,
  }
});
