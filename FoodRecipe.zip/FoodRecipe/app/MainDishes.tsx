import React, { useState } from "react";
import {
  StyleSheet,
  Text,
  View,
  TouchableOpacity,
  Image,
  Modal,
  Dimensions,
  Pressable,
} from "react-native";
import { FlatList, ScrollView } from "react-native-gesture-handler";
import { GestureHandlerRootView } from "react-native-gesture-handler";
import { WebView } from "react-native-webview";

const { width, height } = Dimensions.get("window");
const data = [
  {
    id: "1",
    title: "Biryani",
    image: require("../assets/images/biryani.jpeg"),
    Description:
      "\nA flavorful and aromatic rice dish made with basmati rice, marinated meat (usually chicken, mutton, or beef), and a blend of spices such as cumin, coriander, and saffron.",
    Ingredients:
      "\n• 2 cups basmati rice\n• 500g chicken, mutton, or beef\n• 1 onion, sliced\n• 2 tomatoes, chopped\n• 2 tbsp yogurt\n• 2 tbsp ginger-garlic paste\n• 1 tsp cumin powder\n• 1 tsp coriander powder\n• 1 tsp garam masala\n• 1/4 tsp saffron\n• 4 cups water\n• Salt to taste\n• Fresh cilantro and mint for garnish",
    Instructions:
      "\n1. Marinate the meat with yogurt, ginger-garlic paste, cumin, coriander, and garam masala for at least 2 hours.\n2. In a large pot, cook the rice until 70% done and set aside.\n3. In a separate pan, sauté onions and tomatoes, add the marinated meat and cook until tender.\n4. Layer the cooked rice on top of the meat mixture and sprinkle with saffron, cilantro, and mint.\n5. Cover and cook on low heat for 20-25 minutes.\n6. Serve hot with raita or salad.",
    videoUri: "https://www.youtube.com/embed/uFa6urPkK4c",
  },
  {
    id: "2",
    title: "Karahi Chicken",
    image: require("../assets/images/karahichicken.jpeg"),
    Description:
      "\nA popular Pakistani dish where chicken is cooked in a wok-like pan (karahi) with tomatoes, green chilies, and a variety of spices. It's spicy, flavorful, and perfect with naan or rice.",
    Ingredients:
      "\n• 1 kg chicken, cut into pieces\n• 3 tomatoes, chopped\n• 2 green chilies, chopped\n• 1 tbsp ginger-garlic paste\n• 1 tsp cumin seeds\n• 1 tsp garam masala\n• 1/2 tsp turmeric powder\n• 1 tsp red chili powder\n• Fresh cilantro for garnish\n• Salt to taste",
    Instructions:
      "\n1. Heat oil in a karahi, add cumin seeds and sauté until they splutter.\n2. Add ginger-garlic paste, tomatoes, and green chilies, and cook until the tomatoes soften.\n3. Add chicken pieces and cook until browned.\n4. Add spices (garam masala, turmeric, red chili powder, and salt), and cook for 20 minutes.\n5. Garnish with fresh cilantro and serve with naan or rice.",
    videoUri: "https://www.youtube.com/embed/3d6DrdOEuY4",
  },
  {
    id: "3",
    title: "Seekh Kebabs",
    image: require("../assets/images/seekhkebabs.jpeg"),
    Description:
      "\nMinced meat (usually beef or chicken) mixed with spices and herbs, shaped into long skewers, and grilled until juicy and tender. Served with naan or paratha.",
    Ingredients:
      "\n• 500g minced beef or chicken\n• 1 onion, finely chopped\n• 2 tbsp ginger-garlic paste\n• 1/4 cup cilantro, chopped\n• 1/2 tsp cumin powder\n• 1 tsp garam masala\n• 1/2 tsp red chili powder\n• Salt to taste\n• 2 tbsp oil for grilling",
    Instructions:
      "\n1. In a large bowl, mix minced meat with chopped onions, ginger-garlic paste, cilantro, and spices.\n2. Shape the mixture into long kebabs on skewers.\n3. Preheat the grill and cook the kebabs for 15-20 minutes, turning occasionally, until golden and cooked through.\n4. Serve hot with naan, yogurt, and chutney.",
    videoUri: "https://www.youtube.com/embed/LqLjwiVpjCo",
  },
  {
    id: "4",
    title: "Nihari",
    image: require("../assets/images/nihari.jpeg"),
    Description:
      "\nA slow-cooked beef stew made with a blend of spices like ginger, garlic, and garam masala, traditionally served for breakfast or on special occasions. It is known for its rich and hearty flavor.",
    Ingredients:
      "\n• 500g beef (shank or stew meat)\n• 1 onion, finely sliced\n• 1 tbsp ginger-garlic paste\n• 1 tsp garam masala\n• 1 tsp red chili powder\n• 1/2 tsp turmeric\n• 4 cups water\n• 1/4 cup wheat flour (for thickening)\n• Salt to taste\n• Fresh cilantro for garnish",
    Instructions:
      "\n1. Brown the beef in oil along with onions and ginger-garlic paste.\n2. Add spices (garam masala, red chili powder, turmeric) and cook for 5 minutes.\n3. Add water and cook on low heat for 2-3 hours until the meat is tender.\n4. Mix wheat flour with some water to make a paste, then add to the stew to thicken.\n5. Garnish with fresh cilantro and serve with naan or rice.",
    videoUri: "https://www.youtube.com/embed/1Kd3mhopYaE",
  },
  {
    id: "5",
    title: "Chapli Kebab",
    image: require("../assets/images/chaplikebab.jpeg"),
    Description:
      "\nA traditional Pashtun dish made with minced meat, herbs, and spices, shaped into flat round kebabs and shallow fried until crispy. Served with naan and yogurt.",
    Ingredients:
      "\n• 500g minced beef or mutton\n• 1 onion, finely chopped\n• 2 tomatoes, finely chopped\n• 1/4 cup cilantro, chopped\n• 1 tsp coriander seeds, crushed\n• 1 tsp cumin powder\n• 1/2 tsp red chili powder\n• 1 egg\n• Salt to taste\n• 2 tbsp oil for frying",
    Instructions:
      "\n1. Mix minced meat with chopped onions, tomatoes, cilantro, and spices.\n2. Shape the mixture into flat, round patties.\n3. Heat oil in a pan and shallow fry the kebabs for 4-5 minutes on each side.\n4. Serve with naan and a side of yogurt.",
    videoUri: "https://www.youtube.com/embed/pZfT0-BKNTU",
  },
  {
    id: "6",
    title: "Haleem",
    image: require("../assets/images/haleem.jpeg"),
    Description:
      "\nA savory stew made with wheat, barley, meat (chicken or beef), and lentils, cooked slowly to create a thick, flavorful dish. Often enjoyed during Ramadan or special events.",
    Ingredients:
      "\n• 500g chicken or beef\n• 1/4 cup wheat\n• 1/4 cup barley\n• 1/4 cup lentils\n• 1 onion, chopped\n• 1 tsp ginger-garlic paste\n• 1 tsp garam masala\n• 1/2 tsp cumin powder\n• Salt to taste\n• Fresh cilantro and fried onions for garnish",
    Instructions:
      "\n1. Cook meat, wheat, barley, and lentils together until tender.\n2. Blend the mixture to a smooth paste.\n3. In a separate pan, sauté onions and ginger-garlic paste, then add garam masala and cumin.\n4. Add the blended mixture to the pan and cook until thickened.\n5. Garnish with fried onions and cilantro before serving.",
    videoUri: "https://www.youtube.com/embed/msNXcz5jV0I",
  },
];

const MainDishes = () => {
  const [modalVisible, setModalVisible] = useState(false);
  const [selectedItem, setSelectedItem] = useState(null);
  const [showVideo, setShowVideo] = useState(false);

  const renderItem = ({ item }) => (
    <Pressable
      style={styles.card}
      onPress={() => {
        setSelectedItem(item);
        setShowVideo(false);
        setModalVisible(true);
      }}
    >
      <Image source={item.image} style={styles.image} />
      <Text style={styles.cardTitle}>{item.title}</Text>
      <View style={styles.optionButtons}>
        <TouchableOpacity
          onPress={() => {
            setSelectedItem(item);
            setShowVideo(false);
            setModalVisible(true);
          }}
        >
          <Text style={styles.optionText}>Read</Text>
        </TouchableOpacity>
        <TouchableOpacity
          onPress={() => {
            setSelectedItem(item);
            setShowVideo(true);
            setModalVisible(true);
          }}
        >
          <Text style={styles.optionText}>Watch</Text>
        </TouchableOpacity>
      </View>
    </Pressable>
  );

  const closeModal = () => {
    setModalVisible(false);
    setSelectedItem(null);
  };

  return (
    <GestureHandlerRootView style={{ flex: 1, backgroundColor: "black" }}>
      <Text style={styles.text}>Main Dishes</Text>
      <FlatList
        style={{ marginTop: 30 }}
        data={data}
        renderItem={renderItem}
        keyExtractor={(item) => item.id}
        numColumns={2}
        columnWrapperStyle={styles.row}
      />
      <Modal
        visible={modalVisible}
        animationType="slide"
        onRequestClose={closeModal}
      >
        <View style={styles.modalContainer}>
          {selectedItem && (
            <>
              <Text style={styles.modalTitle}>{selectedItem.title}</Text>
              {showVideo ? (
                <WebView
                  source={{ uri: selectedItem.videoUri }}
                  style={styles.video}
                  javaScriptEnabled={true}
                  domStorageEnabled={true}
                  allowsFullscreenVideo={true}
                />
              ) : (
                <>
                  <ScrollView>
                    <Text style={styles.modalDescription}>
                      {selectedItem.Description}
                    </Text>
                    <Text style={styles.modalIngredients}>
                      Ingredients: {selectedItem.Ingredients}
                    </Text>
                    <Text style={styles.modalInstructions}>
                      Instructions: {selectedItem.Instructions}
                    </Text>
                  </ScrollView>
                </>
              )}
              <TouchableOpacity style={styles.closeButton} onPress={closeModal}>
                <Text style={styles.closeButtonText}>Close</Text>
              </TouchableOpacity>
            </>
          )}
        </View>
      </Modal>
    </GestureHandlerRootView>
  );
};

export default MainDishes;

const styles = StyleSheet.create({
  text: {
    fontSize: 25,
    fontWeight: "bold",
    color: "white",
    textAlign: "center",
    marginTop: "10%",
  },
  row: {
    justifyContent: "space-between",
  },
  card: {
    height: 270,
    width: 170,
    backgroundColor: "#333333",
    borderWidth: 1,
    borderRadius: 10,
    borderColor: "grey",
    marginBottom: 20,
    alignItems: "center",
    justifyContent: "center",
    padding: 10,
    marginHorizontal: 5,
  },
  image: {
    width: "100%",
    height: 170,
    borderRadius: 10,
    marginBottom: 10,
  },
  cardTitle: {
    color: "white",
    fontSize: 18,
    fontWeight: "bold",
    textAlign: "center",
  },
  optionButtons: {
    flexDirection: "row",
    justifyContent: "space-between",
    width: "100%",
    marginTop: 10,
  },
  optionText: {
    color: "orange",
    fontWeight: "bold",
    fontSize: 16,
  },
  modalContainer: {
    flex: 1,
    backgroundColor: "white",
    padding: 20,
  },
  modalTitle: {
    fontSize: 24,
    fontWeight: "bold",
    color: "#333",
    marginBottom: 10,
  },
  modalDescription: {
    fontSize: 16,
    color: "#333",
    marginBottom: 10,
    lineHeight: 22,
  },
  modalIngredients: {
    fontSize: 16,
    color: "#333",
    marginBottom: 10,
    lineHeight: 22,
  },
  modalInstructions: {
    fontSize: 16,
    color: "#333",
    marginBottom: 20,
    lineHeight: 22,
  },
  video: {
    // height: height * 0.2,
    width: width * 0.9,
    borderRadius: 10,
    alignSelf: "center",
  },
  closeButton: {
    backgroundColor: "#FFA500",
    padding: 10,
    borderRadius: 5,
    alignItems: "center",
    marginTop: 20,
  },
  closeButtonText: {
    color: "white",
    fontWeight: "bold",
    fontSize: 16,
  },
  scrollView: {
    marginBottom: 20,
    flex: 1,
  },
});
