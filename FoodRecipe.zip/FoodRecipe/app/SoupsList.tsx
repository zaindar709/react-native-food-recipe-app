import React, { useState } from "react";
import {
  StyleSheet,
  Text,
  View,
  TouchableOpacity,
  Image,
  Modal,
  Dimensions,
  Pressable,
} from "react-native";
import { FlatList, ScrollView } from "react-native-gesture-handler";
import { GestureHandlerRootView } from "react-native-gesture-handler";
import { WebView } from "react-native-webview";

const { width, height } = Dimensions.get("window");

const data = [
  {
    id: "1",
    title: "Chicken Corn Soup",
    image: require("../assets/images/chickencornsoup.jpeg"),
    Description:
      "\nA creamy and flavorful soup made with chicken, corn, and a rich broth, typically served as an appetizer in Pakistani meals.",
    Ingredients:
      "\n• 200g boneless chicken (shredded)\n• 1 cup corn kernels\n• 1/2 cup sweet corn (canned or fresh)\n• 1/2 cup peas\n• 1 onion (finely chopped)\n• 2 cloves garlic (minced)\n• 4 cups chicken stock\n• 1 tsp cornflour (dissolved in water)\n• 1 tsp soy sauce\n• Salt and pepper to taste",
    Instructions:
      "\n1. Heat oil in a pot and sauté onions and garlic until fragrant.\n2. Add chicken and cook until tender.\n3. Pour in chicken stock and bring to a boil.\n4. Add corn, peas, and soy sauce. Let it simmer for 5-10 minutes.\n5. Slowly add the cornflour mixture and stir until thickened.\n6. Pour in the beaten egg while stirring the soup continuously.\n7. Season with salt and pepper. Serve hot.",
    videoUri: "https://www.youtube.com/embed/28FMuKoiYEQ",
  },
  {
    id: "2",
    title: "Lentil Soup (Daal Soup)",
    image: require("../assets/images/dalsoup.jpeg"),
    Description:
      "\nA comforting and nutritious soup made with lentils, providing a rich, thick consistency and earthy flavor.",
    Ingredients:
      "\n• 1 cup red lentils\n• 1 onion (chopped)\n• 1 tomato (chopped)\n• 2 cloves garlic (minced)\n• 1 tsp cumin seeds\n• 1/2 tsp turmeric powder\n• 1 tsp garam masala\n• Salt to taste\n• 4 cups water\n• Fresh cilantro (for garnish)",
    Instructions:
      "\n1. Rinse lentils and set aside.\n2. Heat oil in a pot, and sauté onions and garlic until soft.\n3. Add tomatoes, cumin seeds, turmeric, and garam masala. Cook until tomatoes soften.\n4. Add lentils and water, bring to a boil, then simmer for 30-40 minutes until the lentils are soft.\n5. Blend the soup slightly for a smoother texture (optional).\n6. Garnish with fresh cilantro and serve hot.",
    videoUri: "https://www.youtube.com/embed/BR67V-U72s8",
  },
  {
    id: "3",
    title: "Mutton Shorba",
    image: require("../assets/images/muttonshorba.jpeg"),
    Description:
      "\nA rich, hearty soup made with tender mutton pieces and a blend of aromatic spices, popular in Pakistani households.",
    Ingredients:
      "\n• 500g mutton (bone-in pieces)\n• 1 onion (sliced)\n• 2 tomatoes (chopped)\n• 1 tbsp ginger-garlic paste\n• 2 green chilies (chopped)\n• 1 tsp cumin seeds\n• 1/2 tsp turmeric powder\n• 1 tsp coriander powder\n• 1 tsp garam masala\n• Salt to taste\n• Fresh cilantro for garnish\n• 6 cups water",
    Instructions:
      "\n1. In a large pot, heat oil and sauté onions until golden brown.\n2. Add ginger-garlic paste and green chilies, and cook for another minute.\n3. Add mutton pieces and cook until browned.\n4. Stir in tomatoes, turmeric, cumin, coriander, and salt. Cook until tomatoes soften.\n5. Add water and bring to a boil. Simmer for 1-2 hours until the mutton is tender and the broth is flavorful.\n6. Garnish with fresh cilantro and serve hot.",
    videoUri: "https://www.youtube.com/embed/oKCdDXuXY_4",
  },
  {
    id: "4",
    title: "Chicken Yakhni Soup",
    image: require("../assets/images/chickenyakhni.jpeg"),
    Description:
      "\nA clear and aromatic chicken broth soup made with chicken, ginger, garlic, and whole spices. It’s traditionally served as a light appetizer.",
    Ingredients:
      "\n• 500g chicken (bone-in)\n• 1 onion (whole, peeled)\n• 2 cloves garlic (crushed)\n• 1-inch ginger (sliced)\n• 2-3 green cardamoms\n• 1 bay leaf\n• 1 cinnamon stick\n• 1/2 tsp black peppercorns\n• Salt to taste\n• 6 cups water\n• Fresh cilantro for garnish",
    Instructions:
      "\n1. In a large pot, add chicken, onion, garlic, ginger, cardamom, bay leaf, cinnamon, and peppercorns.\n2. Add water and bring to a boil. Lower the heat and let it simmer for 1-1.5 hours until the chicken is cooked and the broth is flavorful.\n3. Strain the soup and discard the solids.\n4. Adjust salt to taste and garnish with fresh cilantro.\n5. Serve hot.",
    videoUri: "https://www.youtube.com/embed/n5j3xQRaDp8",
  },
  {
    id: "5",
    title: "Palak Soup (Spinach Soup)",
    image: require("../assets/images/palaksoup.jpeg"),
    Description:
      "\nA healthy and nutritious soup made with spinach, garlic, and a blend of spices, this soup is both light and flavorful.",
    Ingredients:
      "\n• 2 cups spinach (fresh or frozen)\n• 1 onion (chopped)\n• 2 cloves garlic (minced)\n• 1/2 tsp cumin seeds\n• 1/2 tsp black pepper powder\n• Salt to taste\n• 4 cups vegetable broth or water\n• Fresh cream (optional)",
    Instructions:
      "\n1. Heat oil in a pot, and sauté onions and garlic until soft.\n2. Add cumin seeds and cook for another minute.\n3. Add spinach and cook until wilted.\n4. Pour in the broth or water and bring it to a boil.\n5. Simmer for 15-20 minutes. Blend the soup until smooth.\n6. Season with salt and black pepper.\n7. Optionally, swirl in some fresh cream before serving.\n8. Serve hot.",
    videoUri: "https://www.youtube.com/embed/1xoNA8Dwa9Y",
  },
  {
    id: "6",
    title: "Vegetable Soup",
    image: require("../assets/images/vegetablesoup.jpeg"),
    Description:
      "\nA healthy and nutritious soup made with spinach, garlic, and a blend of spices, this soup is both light and flavorful.",
    Ingredients:
      "\n• 2 cups spinach (fresh or frozen)\n• 1 onion (chopped)\n• 2 cloves garlic (minced)\n• 1/2 tsp cumin seeds\n• 1/2 tsp black pepper powder\n• Salt to taste\n• 4 cups vegetable broth or water\n• Fresh cream (optional)",
    Instructions:
      "\n1. Heat oil in a pot, and sauté onions and garlic until soft.\n2. Add cumin seeds and cook for another minute.\n3. Add spinach and cook until wilted.\n4. Pour in the broth or water and bring it to a boil.\n5. Simmer for 15-20 minutes. Blend the soup until smooth.\n6. Season with salt and black pepper.\n7. Optionally, swirl in some fresh cream before serving.\n8. Serve hot.",
    videoUri: "https://www.youtube.com/embed/Q4kXLqUiSWI",
  },
];

const SoupsList = () => {
  const [modalVisible, setModalVisible] = useState(false);
  const [selectedItem, setSelectedItem] = useState(null);
  const [showVideo, setShowVideo] = useState(false);

  const renderItem = ({ item }) => (
    <Pressable
      style={styles.card}
      onPress={() => {
        setSelectedItem(item);
        setShowVideo(false);
        setModalVisible(true);
      }}
    >
      <Image source={item.image} style={styles.image} />
      <Text style={styles.cardTitle}>{item.title}</Text>
      <View style={styles.optionButtons}>
        <TouchableOpacity
          onPress={() => {
            setSelectedItem(item);
            setShowVideo(false);
            setModalVisible(true);
          }}
        >
          <Text style={styles.optionText}>Read</Text>
        </TouchableOpacity>
        <TouchableOpacity
          onPress={() => {
            setSelectedItem(item);
            setShowVideo(true);
            setModalVisible(true);
          }}
        >
          <Text style={styles.optionText}>Watch</Text>
        </TouchableOpacity>
      </View>
    </Pressable>
  );

  const closeModal = () => {
    setModalVisible(false);
    setSelectedItem(null);
  };

  return (
    <GestureHandlerRootView style={{ flex: 1, backgroundColor: "black" }}>
      <Text style={styles.text}>Soups List</Text>
      <FlatList
        style={{ marginTop: 30 }}
        data={data}
        renderItem={renderItem}
        keyExtractor={(item) => item.id}
        numColumns={2}
        columnWrapperStyle={styles.row}
      />
      <Modal
        visible={modalVisible}
        animationType="slide"
        onRequestClose={closeModal}
      >
        <View style={styles.modalContainer}>
          {selectedItem && (
            <>
              <Text style={styles.modalTitle}>{selectedItem.title}</Text>
              {showVideo ? (
                <WebView
                  source={{ uri: selectedItem.videoUri }}
                  style={styles.video}
                  javaScriptEnabled={true}
                  domStorageEnabled={true}
                  allowsFullscreenVideo={true}
                />
              ) : (
                <>
                  <ScrollView>
                    <Text style={styles.modalDescription}>
                      {selectedItem.Description}
                    </Text>
                    <Text style={styles.modalIngredients}>
                      Ingredients: {selectedItem.Ingredients}
                    </Text>
                    <Text style={styles.modalInstructions}>
                      Instructions: {selectedItem.Instructions}
                    </Text>
                  </ScrollView>
                </>
              )}
              <TouchableOpacity style={styles.closeButton} onPress={closeModal}>
                <Text style={styles.closeButtonText}>Close</Text>
              </TouchableOpacity>
            </>
          )}
        </View>
      </Modal>
    </GestureHandlerRootView>
  );
};

export default SoupsList;

const styles = StyleSheet.create({
  text: {
    fontSize: 25,
    fontWeight: "bold",
    color: "white",
    textAlign: "center",
    marginTop: "10%",
  },
  row: {
    justifyContent: "space-between",
  },
  card: {
    height: 270,
    width: 170,
    backgroundColor: "#333333",
    borderWidth: 1,
    borderRadius: 10,
    borderColor: "grey",
    marginBottom: 20,
    alignItems: "center",
    justifyContent: "center",
    padding: 10,
    marginHorizontal: 5,
  },
  image: {
    width: "100%",
    height: 170,
    borderRadius: 10,
    marginBottom: 10,
  },
  cardTitle: {
    color: "white",
    fontSize: 18,
    fontWeight: "bold",
    textAlign: "center",
  },
  optionButtons: {
    flexDirection: "row",
    justifyContent: "space-between",
    width: "100%",
    marginTop: 10,
  },
  optionText: {
    color: "orange",
    fontWeight: "bold",
    fontSize: 16,
  },
  modalContainer: {
    flex: 1,
    backgroundColor: "white",
    padding: 20,
  },
  modalTitle: {
    fontSize: 24,
    fontWeight: "bold",
    color: "#333",
    marginBottom: 10,
  },
  modalDescription: {
    fontSize: 16,
    color: "#333",
    marginBottom: 10,
    lineHeight: 22,
  },
  modalIngredients: {
    fontSize: 16,
    color: "#333",
    marginBottom: 10,
    lineHeight: 22,
  },
  modalInstructions: {
    fontSize: 16,
    color: "#333",
    marginBottom: 20,
    lineHeight: 22,
  },
  video: {
    // height: height * 0.2,
    width: width * 0.9,
    borderRadius: 10,
    alignSelf: "center",
  },
  closeButton: {
    backgroundColor: "#FFA500",
    padding: 10,
    borderRadius: 5,
    alignItems: "center",
    marginTop: 20,
  },
  closeButtonText: {
    color: "white",
    fontWeight: "bold",
    fontSize: 16,
  },
  scrollView: {
    marginBottom: 20,
    flex: 1,
  },
});
